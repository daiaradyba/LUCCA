class Log extends BaseClass {
    constructor(x, y, height, angle) {
     super(x,y,100,height,angle);
     this.image = loadImage("sprites/wood2.png")
     //x,y,width,height,angle
    }
    
  };
  